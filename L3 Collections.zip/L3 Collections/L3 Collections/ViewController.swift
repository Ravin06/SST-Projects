//
//  ViewController.swift
//  L3 Collections
//
//  Created by RAVIN NAGPAL on 15/4/21.
//

import UIKit

class ViewController: UIViewController {
    //Outlets
    @IBOutlet weak var button_bmi: UIButton!
    @IBOutlet weak var button_rgb: UIButton!
    @IBOutlet weak var web_button: UIButton!
    @IBOutlet weak var button_picker: UIButton!
    @IBOutlet weak var button_table: UIButton!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        button_bmi.layer.cornerRadius = 10
        button_rgb.layer.cornerRadius = 10
        web_button.layer.cornerRadius = 10
        button_picker.layer.cornerRadius = 10
        button_table.layer.cornerRadius = 10
    }


}

