//
//  infoVC.swift
//  L3 Collections
//
//  Created by RAVIN NAGPAL on 22/4/21.
//

import UIKit

class infoVC: UIViewController {
    var selectedRow: Int?
    let pd = data()
    
    // outlets
    @IBOutlet weak var imageview: UIImageView!
    @IBOutlet weak var textview: UITextView!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.title = pd.pokemon[selectedRow!]
        imageview.image = UIImage(named: pd.image[selectedRow!])
        textview.text = pd.info[selectedRow!]
    }
}
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


